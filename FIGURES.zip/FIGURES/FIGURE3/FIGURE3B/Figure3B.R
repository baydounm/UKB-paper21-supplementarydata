# Load necessary libraries
library(ggplot2)
library(dplyr)
library(ggrepel)  # For non-overlapping labels

# Set working directory for FIGURE3B
setwd("E://16GBBACKUPUSB//BACKUP_USB_SEPTEMBER2014//May Baydoun_folder//UK_BIOBANK_PROJECT//UKB_PAPER14_ADPRSDEM_METABOLOMIC//FIGURES//FIGURE3//FIGURE3B//")
# Load the datasets
list_metabolites <- read.csv("List_METABOLITES.csv")
regression_results <- read.csv("regression_results_NEWADPRS.csv")

# Merge datasets on Fieldnum
merged_data <- merge(regression_results, list_metabolites, by = "Fieldnum")

# Filter for labeling significant hits and assign colors
merged_data <- merged_data %>%
  mutate(log10p = -log10(p),
         label = ifelse(estimate > 0.07 | estimate < -0.07, Abbreviation, NA),
         color = ifelse(estimate > 0.05, "red", ifelse(estimate < -0.05, "blue", "black")))

# Bonferroni correction line for the y-axis
bonferroni_cutoff <- -log10(0.05 / 249)

# Compute maximum log10p for extra vertical space (e.g., 20% extra)
max_y <- max(merged_data$log10p, na.rm = TRUE)
upper_limit <- max(max_y * 1.2, bonferroni_cutoff * 1.05)

# Create the volcano plot with vertical threshold lines, adjusted axes, and extra space for labels
volcano_plot <- ggplot(merged_data, aes(x = estimate, y = log10p)) +
  geom_point(aes(color = color), alpha = 0.7) +  
  geom_hline(yintercept = bonferroni_cutoff, linetype = "dashed", color = "grey") +  # Bonferroni threshold
  geom_vline(xintercept = c(-0.05, 0.05), linetype = "dashed", color = "blue") +    # ±0.05 threshold
  geom_vline(xintercept = c(-0.07, 0.07), linetype = "dashed", color = "blue") +    # ±0.07 threshold
  geom_text_repel(aes(label = label), size = 3, na.rm = TRUE, max.overlaps = Inf,
                  box.padding = 0.5, point.padding = 0.5, force = 5, segment.size = 0.2) +
  scale_x_continuous(breaks = c(-0.10, -0.07, -0.05, 0, 0.05, 0.07, 0.10, 0.15)) +
  scale_y_continuous(limits = c(0, upper_limit)) +  # Adjust y-axis to include the Bonferroni cutoff
  theme_classic() +  # Keeps axis lines but removes grid lines
  labs(title = "Volcano Plot of New AD PRS vs. metabolites",
       x = "Estimate",
       y = "-log10(p-value)") +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_color_identity()

# Print the plot
print(volcano_plot)

# Save the plot as a JPEG file with specified dimensions and resolution
ggsave("Figure3B.jpeg", plot = volcano_plot, device = "jpeg",
       width = 7, height = 5, dpi = 300)
