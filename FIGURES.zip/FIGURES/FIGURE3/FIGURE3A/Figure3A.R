# Load necessary libraries
library(ggplot2)
library(dplyr)
library(ggrepel)  # For non-overlapping labels

setwd("C:/Users/huy13/Box/Projects/May/Paper14/Paper so far/FIGURE3/FIGURE3A/")
# Load the datasets
list_metabolites <- read.csv("List_METABOLITES.csv")
regression_results <- read.csv("regression_results_ADPGS.csv")

# Merge datasets on Fieldnum
merged_data <- merge(regression_results, list_metabolites, by = "Fieldnum")

# Filter for labeling significant hits and assign colors
merged_data <- merged_data %>%
  mutate(log10p = -log10(p),
         label = ifelse(estimate > 0.07 | estimate < -0.07, Abbreviation, NA),
         color = ifelse(estimate > 0.05, "red", ifelse(estimate < -0.05, "blue", "black")))

# Bonferroni correction line for the y-axis
bonferroni_cutoff <- -log10(0.05 / 249)

# Compute maximum log10p to extend y-axis for label space
max_y <- max(merged_data$log10p, na.rm = TRUE)

# Create the volcano plot with extra y-axis space
volcano_plot <- ggplot(merged_data, aes(x = estimate, y = log10p)) +
  geom_point(aes(color = color), alpha = 0.7) +  
  geom_hline(yintercept = bonferroni_cutoff, linetype = "dashed", color = "grey") +  # Bonferroni line
  geom_vline(xintercept = c(-0.05, 0.05), linetype = "dashed", color = "blue") +   # Effect size threshold at ±0.05
  geom_vline(xintercept = c(-0.07, 0.07), linetype = "dashed", color = "blue") +   # Effect size threshold at ±0.07
  geom_text_repel(aes(label = label), size = 3, na.rm = TRUE, max.overlaps = Inf, 
                  box.padding = 0.5, point.padding = 0.5, force = 5, segment.size = 0.2) +
  scale_x_continuous(breaks = c(-0.10, -0.07, -0.05, 0, 0.05, 0.07, 0.10, 0.15),
                     limits = c(-0.10, 0.15)) +
  scale_y_continuous(limits = c(0, max_y * 1.2)) +  # Increase y-axis limit by 20%
  theme_classic() +  # Keeps x and y axis lines while removing grid lines
  labs(title = "Volcano Plot of AD PGS vs. metabolites",
       x = "Estimate",
       y = "-log10(p-value)") +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_color_identity()

# Print the plot
print(volcano_plot)

ggsave("Figure3A.jpeg", plot = volcano_plot, device = "jpeg", width = 7, height = 5, dpi = 300)
