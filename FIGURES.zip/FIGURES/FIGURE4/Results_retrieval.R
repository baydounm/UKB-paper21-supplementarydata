# Load libraries
library(dplyr)
library(stringr)
library(tibble)
library(tidyr)
library(purrr)
library(janitor)
library(readxl)

# path to .smcl file
smcl_file <- "C:/Users/huy13/Box/Projects/May/Paper14/Paper so far/GSEMMODEL_ADPGS_DEM_AD_INDMETABOLITES.smcl"  # <-- Replace with your file path

# Read the file; each element of smcl_lines is a line from the file
smcl_lines <- readLines(smcl_file, warn = FALSE)

# Create a dataframe from the lines
output <- tibble(line = smcl_lines)

# Filter rows
output_filtered <- output %>%
  filter(str_detect(line, "stset") | (str_detect(line, "Response") & str_detect(line, "zln_n")) | (str_detect(line, "space 7") & str_detect(line, "_nl_1"))) %>% 
  mutate(
    # For rows with "stset": extract the string inside failure( ) (either "dem_diag==1" or "ad_diag==1")
    outcome = if_else(str_detect(line, "stset"),
                      str_extract(line, "(?<=failure\\()[^)]+(?=\\))"),
                      NA_character_),
    # For rows with "Response": extract the number directly appended to "zln_n_"
    Fieldnum = if_else(str_detect(line, "Response"),
                       str_extract(line, "(?<=zln_n_)\\d+"),
                       NA_character_),
    # For rows with "_nl_1": extract the six numbers.
    # The first five numbers are expected to be between a } and a { (with optional spaces).
    # The sixth number follows a } (without an opening brace after it).
    nl1_list = map(line, ~ {
      if (str_detect(.x, "_nl_1")) {
        # Extract all numbers that follow a } (ignoring the following character)
        numbers <- str_extract_all(.x, "(?<=\\})\\s*(-?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?)")[[1]]
        if (length(numbers) >= 6) {
          numbers[1:6]
        } else {
          rep(NA, 6)
        }
      } else {
        rep(NA, 6)
      }
    })
  )

output_cleaned <- output_filtered %>%
  unnest_wider(nl1_list, names_sep = "_") %>% 
  fill(outcome, Fieldnum, .direction = "down") %>% 
  rename(
    coeff     = nl1_list_1,
    ste      = nl1_list_2,
    z         = nl1_list_3,
    p         = nl1_list_4,
    c95lower = nl1_list_5,
    c95upper = nl1_list_6
  ) %>% 
  filter(!is.na(coeff)) %>% 
  mutate(across(c(coeff, ste, z, p, c95lower, c95upper), as.numeric)) %>% 
  select(-line) %>% 
  mutate(dementia_type = ifelse(outcome == "dem_diag==1", "dem", "AD")) %>% 
  select(-outcome) %>% 
  group_by(dementia_type, Fieldnum) %>%
  mutate(nlcom_model = row_number()) %>%
  ungroup() %>% 
  select(dementia_type, Fieldnum, nlcom_model, everything())

# Sanity check
tabyl(output_cleaned, dementia_type)

# Merge back to the metabolite names
List_METABOLITES <- read_excel("C:/Users/huy13/Box/Projects/May/Paper14/List_METABOLITES.xlsx")

final_output <- output_cleaned %>% mutate(Fieldnum = as.numeric(Fieldnum)) %>% left_join(List_METABOLITES, by = "Fieldnum") %>% 
  select(dementia_type, Fieldnum, Full_name, Abbreviation, nlcom_model, everything())

# Save output
write.csv(final_output, "C:/Users/huy13/Box/Projects/May/Paper14/Output/main_AD_PGS_perc_mediated_results.csv", row.names = FALSE)